-- This is the primary core of CS:GO.
-- The secondary core is cs_register


cs_core = {}


sum = 0
local modpath = core.get_modpath(minetest.get_current_modname())
-- Make main variable for use.

--[[
for cs_coret, def in pairs(cs_core.var) do -- Insert
	cs_core.var[cs_coret] = {count = 0, counter = 0, terrorist = 0}
	table.insert(cs_core.null, team) -- Null.
end
--]]
--Dofiles...

dofile(modpath.."/cooldown.lua") -- CoolDown MINI-API
dofile(modpath.."/api.lua") -- API
dofile(modpath.."/l_j.lua") -- Leave/Join.

minetest.register_on_joinplayer(function(player)
local hud = mhud.init()
local playern = player:get_player_name()
hud:add(player, "screen", {
		hud_elem_type = "image",
		position = {x = 0.5, y = 0.5},
		image_scale = -100,
		texture = "screen.png"
})
end)



cs_death = {
	team = {
		counter = {pos=false},
		terrorist = {pos=false},
		spectator = {pos=false},
	},


}

function cs_death.register_spawn(team, position)
		
		
		if team == "spectator" then
		cs_death.team.spectator.pos = position -- Enable variable
		end
		
		if team == "terrorist" then
		cs_death.team.terrorist.pos = position -- Enable variable
		end
		
		if team == "counter" then
		cs_death.team.counter.pos = position -- Enable variable
		end
		
		if team == "all" then
		cs_death.team.counter.pos = position -- Enable variable
		cs_death.team.terrorist.pos = position -- Enable variable
		cs_death.team.spectator.pos = position -- Enable variable
		end
		
end
registered = {}
for ppp in pairs(minetest.get_connected_players()) do
sum = sum + 1
end

minetest.register_chatcommand("gamee", {
    func = function(name)
	cs_core.log("action", "Starting Maps/Env")
	minetest.clear_objects({ mode = "quick" })
	cs_map.new_match()
	cs_death.register_spawn("all", spectators_spawn()) -- ALL: terrorists and counters, spectators_spawn(): where the spectators spawn
        
    end,
})





function cs_core.new_match()
cs_core.log("action", "Starting Maps/Env")
minetest.clear_objects({ mode = "quick" })
--[[
cs_death.register_spawn("terrorist", terrorists_spawn()) -- Only this is enabled when the mode is other
cs_death.register_spawn("counter", counters_spawn())
--]]

cs_map.new_match()
cs_death.register_spawn("all", spectators_spawn()) -- ALL: terrorists and counters, spectators_spawn(): where the spectators spawn
end
























