-- Only API and Menu

cs_core.main_seconds = 10

csgo = {
	team = { -- All modes need a variable "inf" registered with a value "true" for valid team.
		counter = {}, -- Counter Terrorist Forces
		terrorist = {}, -- Terrorist Forces
		spectator = {}, -- When a player die. Turns into a spectator
	},
	ctl = {}, -- Current team list
	op = {}, -- Online Players, DEF_L1:::=If a player are in those three teams {c,t,s}
	pt = {}, -- Player team
	pot = {}, -- Name of team in a player ENV
	teams = {}, -- DEF:::={inf=nil}
	online = {},
	usrTlimit = 10,
}

cs = {}

for team, def in pairs(csgo.team) do -- Insert
	csgo.team[team] = {count = 0, players = {}, inf = true}
	table.insert(csgo.ctl, team)
end

function csgo.send_message(message, team, player) -- Send a message to every player in the specified team.
	if (csgo.team[team].inf == true) then -- Verify team before continue.
		for aplayer, def in pairs(csgo.team[team].players) do
			if (player) then
				core.chat_send_player(aplayer, "[" .. player .. "] " .. message)
			else
				core.chat_send_player(aplayer, message)
			end
		end
	end
end

function csgo.terrorist(player)
	if (not csgo.op[player] == true) then
		local ttt = "terrorist"
		csgo.op[player] = true
		csgo.pt[player] = true
		csgo.online[player] = true
		csgo.pot[player] = "terrorist"
		csgo.team[ttt].count = csgo.team[ttt].count + 1
		cs_core.can_do_damage(player, "yes") -- Can do damage to every player
		csgo.team[ttt].players[player] = true -- Put that plater in terrorist team. DEF:::={inf="L22", search="terrorist"}
		csgo.send_message(player .. " Joins the Terrorist forces", ttt)
	end
end

function csgo.counter(player)
	if (not csgo.op[player] == true) then
		local ttt = "counter"
		csgo.op[player] = true
		csgo.pt[player] = true
		csgo.online[player] = true
		csgo.pot[player] = "counter"
		csgo.team[ttt].count = csgo.team[ttt].count + 1
		cs_core.can_do_damage(player, "yes") -- Can do damage to every player.
		csgo.team[ttt].players[player] = true -- Put that plater in counter team. DEF:::={inf="L48", search="counter"}
		core.chat_send_player(player, "E2")
		csgo.send_message(player .. " Joins the Counter-Terrorist forces", ttt)
	end
end

function csgo.spectator(player, reason) -- Called when he are died or directly turns into a spectator from menu
	local ttt = "spectator"
	csgo.op[player] = nil -- Disable him
	csgo.pt[player] = nil -- Disable him
	csgo.online[player] = true
	csgo.pot[player] = ttt
	csgo.team[ttt].count = csgo.team[ttt].count + 1
	cs_core.can_do_damage(player, "no") -- Cant put damage to playing players
	csgo.team[ttt].players[player] = true -- Put that plater in spectator-mode team. DEF:::={inf="L48", search="spectator"}
	if (reason) then
	csgo.send_message(player .. " " .. reason, ttt) -- No building auto-reasons by machine!
	end
end

function preparenow()
cs_core.main_seconds = cs_core.main_seconds - 1
end

function csgo.main(name)
    local minute = cs_core.main_seconds
    local formspec = {
        "formspec_version[6]" ..
	"size[17,11]" ..
	"box[0,1.1;18.4,11;#fc0000]" ..
	"box[0,0;17.5,1.1;#ff4400]" ..
	"label[0.3,0.5;Counter Strike Like]" ..
	"label[13.9,0.5;Version: 0.1-BETA]" ..
	"button[0,1.1;6.2,7.6;counterr;Counters\n Bots: " .. minetest.formspec_escape(csgo.team.counter.count) .."\n Players: " .. minetest.formspec_escape(csgo.team.counter.count) .. " ]" ..
	"button[10.8,1.1;6.2,7.6;countert;Counter Terrorists\n Bots: " .. minetest.formspec_escape(csgo.team.terrorist.count) .."\n Players: " .. minetest.formspec_escape(csgo.team.terrorist.count) .. " ]" ..
	"label[4.3,10.4; Select Fast!! in 10 seconds this menu closes and theres no back!]" ..
	"label[0.7,9; Theres a limit of players in every team\n Terrorists Limit: 10\n Counters Limit: 10\n]" ..
	"button[7,1.3;3,5.6;spect;Spectator]"
    }

    return table.concat(formspec, "")
end



minetest.register_on_dieplayer(function(player, reason)
	local pname = player:get_player_name()
	if csgo.pot[pname] then
		csgo.spectator(pname)
		local debug_info = "RR={" .. minetest.serialize(reason) .. "}"
		csgo.send_message(pname .. "will be a spectator. because he died. " .. debug_info, "spectator")
	end
	print(reason) -- DEBUG
end)


minetest.register_on_player_receive_fields(function(player, formname, fields)
    if formname ~= "core:main" then
        return
    end
		
	if fields.countert then
        local pname = player:get_player_name()
        csgo.terrorist(pname) 
        core.close_formspec(pname, "core:main")
    	
    end
    
    if fields.counterr then
        local pname = player:get_player_name()
        csgo.counter(pname)
        core.close_formspec(pname, "core:main")
    end
    
    
    if fields.spect then
        local pname = player:get_player_name()
        local var = pname .. " will be a spectator, reason: no died but required from main menu."
        csgo.spectator(pname, var)
        core.close_formspec(pname, "core:main")
    end
end)



function temp(name)
    minetest.show_formspec(name, "core:main", csgo.main(name))
end
minetest.register_chatcommand("t", {
    func = function(name, param)
    	local team = csgo.pot[name]
    	if team == "counter" then
        csgo.send_message(minetest.colorize("#3491FF", "** " .. param .. " **"), team, name)
        elseif team == "terrorist" then
        csgo.send_message(minetest.colorize("#FFA900", "** " .. param .. " **"), team, name)
        elseif team == "spectator" then
        csgo.send_message(minetest.colorize("#00C200", "** " .. param .. " **"), team, name)
        end
        
    end,
})
minetest.register_chatcommand("gameee", {
    func = function(name)
    	for i = 1, 10 do
    	
    	preparenow()
    	temp(name)
    	cs_core.cooldown(1)
    	end
        
    end,
})


function terminate(var, pname) -- This has a players act

if (csgo.team.terrorist.count > csgo.team.counter.count) then
csgo.counter(pname)
end
if (csgo.team.counter.count > csgo.team.terrorist.count) then
csgo.terrorist(pname)
end
if (csgo.team.counter.count == csgo.usrTlimit and csgo.team.terrorist.count == csgo.usrTlimit) then
csgo.spectator(pname)
end
if (csgo.team.counter.count == 0 and csgo.team.terrorist.count == 0) then
	if var == 1 then
	csgo.counter(pname)
	end
	if var == 2 then
	csgo.terrorist(pname)
	end
end

end








function doit()

term_var = math.random(1, 2)
terminate(term_var, name)
core.close_formspec(name, "core:main")

end

minetest.register_on_joinplayer(function(playerrrr)
	name = playerrrr:get_player_name()
    	preparenow()
    	temp(name)
    	
    	minetest.register_on_player_receive_fields(function(player, formname, fields)
    	if formname == "core:main" and player == playerrrr then
        return
        else
        minetest.after(10, doit)
    	end
    	
    	end)
    	minetest.after(10, doit) -- hehe, here must be an error but its solved a long time ago in top of this file
    	
end)






