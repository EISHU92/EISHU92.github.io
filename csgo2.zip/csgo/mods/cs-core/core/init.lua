local modpath = core.get_modpath(minetest.get_current_modname())
dofile(modpath.."/core1.lua") -- Primary Core
dofile(modpath.."/core2.lua") -- Secondary Core
